package me.qyh.downinsrun;

import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import javax.swing.SwingUtilities;

public class Downloader {

	private static final Path config = Paths.get(System.getProperty("user.home")).resolve("downins")
			.resolve("config.properties");

	static {
		try {
			Files.createDirectories(config.getParent());
			if (!Files.exists(config)) {
				Files.createFile(config);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void main(String[] args) throws Exception {
		String type = args[0];
		if (!type.equalsIgnoreCase("u") && !type.equalsIgnoreCase("p")) {

			if (type.equalsIgnoreCase("s")) {
				processSetting(args);
				return;
			}
			prtError("无效的类型，只支持用户|帖子的下载");
		}
		if (args.length < 2) {
			prtError("无效的参数");
		}
		String url = args[1];
		Optional<String> opsign = InsParser.parse(url);
		if (!opsign.isPresent()) {
			prtError("无法解析的地址或标识");
		}

		Path dir = Configure.get().getConfig().getDownloadDir();
		String sign = opsign.get();
		System.out.println("开始执行任务");
		long start = System.currentTimeMillis();
		if ("p".equalsIgnoreCase(type)) {
			new DownloadP(sign, dir).start();
		}
		if ("u".equalsIgnoreCase(type)) {
			new DownloadU(sign, dir).start();
		}
		long end = System.currentTimeMillis();
		System.out.println("任务执行完毕，共计耗时:" + (end - start) / 1000 + "s，系统即将退出");
		System.exit(0);
	}

	private static final String[] VALID_KEYS = { "threadNum", "location", "proxyPort", "proxyAddr", "sid" };
	private static final StringBuilder validKeysString = new StringBuilder();

	static {
		for (String vk : VALID_KEYS) {
			validKeysString.append(vk).append(",");
		}
		validKeysString.deleteCharAt(validKeysString.length() - 1);
	}

	private static boolean isValidKey(String key) {
		for (String vk : VALID_KEYS) {
			if (key.equalsIgnoreCase(vk)) {
				return true;
			}
		}
		return false;
	}

	private static void processSetting(String[] args) {
		if (GraphicsEnvironment.isHeadless()) {
			if (args.length == 1) {
				System.exit(0);
			}
			DowninsConfig config = new DowninsConfig();

			boolean setThreadNum = false;
			boolean setLocation = false;
			boolean setProxyAddr = false;
			boolean setProxyPort = false;
			boolean setSid = false;

			for (int i = 1; i < args.length; i++) {
				String arg = args[i];
				int index = arg.indexOf('=');
				if (index == -1) {
					prtError("配置参数应该包含=号，例如threadNum=5");
				}
				String key = arg.substring(0, index);
				String value = arg.substring(index + 1, arg.length());

				if (!isValidKey(key)) {
					prtError("无效的配置名项:" + key + "，有效的配置项为" + validKeysString);
				}

				if (key.equalsIgnoreCase("threadNum")) {
					setThreadNum = true;
					try {
						config.setThreadNum(Integer.parseInt(value));
					} catch (NumberFormatException e) {
						prtError("下载线程数必须为数字");
					}
				}

				if (key.equalsIgnoreCase("sid")) {
					setSid = true;
					config.setSid(value);
				}

				if (key.equalsIgnoreCase("location")) {
					setLocation = true;
					config.setLocation(value);
				}

				if (key.equalsIgnoreCase("proxyAddr")) {
					setProxyAddr = true;
					config.setProxyAddr(value);
				}

				if (key.equalsIgnoreCase("proxyPort")) {
					setProxyPort = true;
					if (!value.isEmpty()) {
						try {
							config.setProxyPort(Integer.parseInt(value));
						} catch (NumberFormatException e) {
							prtError("代理端口必须为数字");
						}
					}
				}

				DowninsConfig prev = Configure.get().getConfig();
				if (!setLocation)
					config.setLocation(prev.getLocation());
				if (!setProxyAddr)
					config.setProxyAddr(prev.getProxyAddr());
				if (!setProxyPort)
					config.setProxyPort(prev.getProxyPort());
				if (!setSid)
					config.setSid(prev.getSid());
				if (!setThreadNum)
					config.setThreadNum(prev.getThreadNum());

			}
			try {
				Configure.get().store(config);
			} catch (LogicException e) {
				prtError(e.getMessage());
			} catch (IOException e) {
				prtError("保存失败");
			}

		} else {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					new SettingFrame();
				}
			});
		}
	}

	private static void prtError(String msg) {
		System.out.println(msg);
		System.exit(-1);
	}

}
